# Ochi Website Clone created with

✅ Next JS
✅ React JS
✅ TypeScript
✅ Tailwind CSS
✅ GSAP
✅ Framer Motion
✅ Locomotive Scroll

<hr/>

![OCHI - Presentation Design Agency and 2 more pages - Personal - Microsoft​ Edge 5_26_2024 4_34_03 AM](https://github.com/devwithzain/ochi-website-clone/assets/131141179/d47be37b-efa0-45f0-bb18-1c5aed00191b)
