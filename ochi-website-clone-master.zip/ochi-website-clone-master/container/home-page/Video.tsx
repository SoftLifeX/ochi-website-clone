import { PlayVideo } from "@/components";

export default function Video() {
	return <PlayVideo videosrc="/homevideo.mp4" />;
}
